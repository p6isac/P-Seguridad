<?php

	function mod($a,$b){
		
		$r=$a%$b;
		if($b<0)
			$b=abs($b);
		if($r<0)
			$r=$r+$b;
		return $r;
			
	}

	$a=-13;
	$b=64;
	$r=mod($a,$b);
	echo $r;

?>
	