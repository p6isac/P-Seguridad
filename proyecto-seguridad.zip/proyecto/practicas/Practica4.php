<?php

	$cuenta=$_POST['number'];
	$arreglo=str_split($cuenta);
	if(count($arreglo)<9){
		echo "No es un número válido";}
	else{
			$cifrar=array_reverse($arreglo);
			shuffle($cifrar);
			$cifrado=implode("",$cifrar);
			echo "Su No.cuenta cifrado es:</br>";
			echo $cifrado."47";
	}	
	 
?>

	