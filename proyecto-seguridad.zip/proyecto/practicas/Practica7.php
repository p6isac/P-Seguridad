<?php

	function hashed(){
		$contraseña=$_POST['pass'];
		$desordena=str_shuffle($contraseña);
		$mayuscula=strtoupper($desordena);
		$alrevez=strrev($mayuscula);
		$subs=substr($alrevez,2,-1);
		return $subs;	
		
	}
	
	$usuario=$_POST['usu'];
	$hash=hashed();
	echo "Eres el usuario:$usuario";
	echo "<br/>";
	echo "Tu hash de contraseña es:$hash";

?>