<?php

//Dadas una cadena y una llave, implementar un algoritmo de cifrado simétrico





?>