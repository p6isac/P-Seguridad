<?php

	$connect=mysqli_connect("localhost","root","clave","SEGURIDAD");
	/*if(!$connect){
		
		echo "No se pudo conectar";
	}else{

		echo "Conexion exitosa";
	}*/
	//Recibiendo los datos
	$nom=$_POST['nombre'];
	$contra=$_POST['clave'];
	//Insertar a la base
	$insertar="INSERT INTO USUARIOS(Nombre,Clave) VALUES ('$nom','$contra')";
	//Esta parte es para que cheque si ya hay un usuario con el mismo nombre y entonces no lo vuelvaa registrar
	$verificar_usuario=mysqli_query($connect, "SELECT * FROM USUARIOS WHERE nombre='$nom'");
	if(mysqli_num_rows($verificar_usuario)>0){
		echo '<script> 
				alert("El usuario ya esta registrado");
				window.history.go(-1);
				</script>';
		exit;
	}	
	
	
	
	
	
	//Ejecutar consulta
	$res=mysqli_query($connect,$insertar);
	
	if(!$res){
	echo "Error al registrarse";
	}else{
		echo 
		'<script> alert("Usuario registrado");</script>';
	}
	mysqli_close($connect);

?>