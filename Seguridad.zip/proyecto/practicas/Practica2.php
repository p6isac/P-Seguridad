<?php

function codificar($str){
$abc=array('a'=>'0.','b'=>'0..','c'=>'0...','d'=>'.0','e'=>'..0','f'=>'...0','g'=>'0_','h'=>'0__','i'=>'0___','j'=>'___0','k'=>'__0','l'=>'_0','m'=>'0-','n'=>'0--','o'=>'0---','p'=>'---0','q'=>'--0','r'=>'-0','s'=>'0>','t'=>'0>>','u'=>'0>>>','v'=>'<<<0','w'=>'<<0','x'=>'<0','y'=>'0*','z'=>'*0');
$codi=strtr($str,$abc);
return $codi;
}

$str='Buenos diaS';
$str=strtolower($str);
$codi=codificar($str);
echo $codi;

?>
	



