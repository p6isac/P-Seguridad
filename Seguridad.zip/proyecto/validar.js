
	function validar()
	{
	
		var nombre;
		var contraseña;
		var expresion;
		nombre = document.getElementById("nombre").value;
		contraseña = document.getElementById("contraseña").value;
		expresion = /^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{4,15}$/;
		//Contraseña con minimo cuatro caracteres maximo 15, por lo menos un digito y tambien una minuscua y mayuscula
		
		if(nombre == "" || contraseña == ""){
		alert("Todos los campos son obligatorios!!");
		return false;
		}
		else if(nombre.length>30){
			alert("El nombre es muy largo!!");
			return false;
		}
		else if(contraseña.length>15){
			alert("La contraseña es muy larga");
			return false;
	    }
		else if(!expresion.test(contraseña)){	
			alert("La contraseña no es valida");
			return false;		
		}



	}